#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import setuptools

setuptools.setup(
    name="setup",
    version="1.0",
    author="Miguel Sanchez",
    author_email="migueldasb@gmail.com",
    description="A package to work in this study",
    url="https://github.com/trimiguel/tfm",
    packages=setuptools.find_packages()
)

